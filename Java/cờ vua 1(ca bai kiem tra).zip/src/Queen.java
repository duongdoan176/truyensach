import java.util.ArrayList;

public class Queen extends Piece {
    /**
     * queen.
     */
    public Queen(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    /**
     * queen.
     */
    public Queen(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    @Override
    public String getSymbol() {
        return "Q";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        boolean kq = false;
        ArrayList<Piece> pieces = board.getPieces();
        int tong = x + y;
        int hieu = x - y;
        if (getCoordinatesX() + getCoordinatesY() != tong
                && getCoordinatesX() - getCoordinatesY() != hieu) {
            return false;
        }
        if (getCoordinatesX() + getCoordinatesY() == tong) {
            boolean test = false;
            for (Piece piece : pieces) {
                int tong1 = piece.getCoordinatesX() + piece.getCoordinatesY();
                if (tong1 == tong
                        && piece.getCoordinatesX() != x
                        && piece.getCoordinatesY() != y
                        && piece.getCoordinatesX() != getCoordinatesX()
                        && piece.getCoordinatesY() != getCoordinatesY()) {
                    double result1 = Math.round(distance(piece) * 1000.0) / 1000.0;
                    double result2 = Math.round(piece.distance(x, y) * 1000.0) / 1000.0;
                    double result3 = Math.round(distance(x, y) * 1000.0) / 1000.0;
                    if (result3 == result1 + result2) {
                        test = true;
                        kq = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 != null) {
                    kq = false;
                }
                if (piece1 == null && piece1.getColor() == getColor()) {
                    kq = false;
                }
            }
        }
        if (getCoordinatesX() - getCoordinatesY() == hieu) {
            boolean test = false;
            for (Piece piece : pieces) {
                int hieu1 = piece.getCoordinatesX() - piece.getCoordinatesY();
                if (hieu1 == hieu
                        && piece.getCoordinatesX() != x
                        && piece.getCoordinatesY() != y
                        && piece.getCoordinatesX() != getCoordinatesX()
                        && piece.getCoordinatesY() != getCoordinatesY()) {
                    double result1 = Math.round(distance(piece) * 1000.0) / 1000.0;
                    double result2 = Math.round(piece.distance(x, y) * 1000.0) / 1000.0;
                    double result3 = Math.round(distance(x, y) * 1000.0) / 1000.0;
                    if (result3 == result1 + result2) {
                        test = true;
                        kq = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 != null) {
                    kq = false;
                }
                if (piece1 == null && piece1.getColor() == getColor()) {
                    kq = false;
                }
            }
        }
        if (getCoordinatesX() == x) {
            boolean test = false;
            for (Piece piece : pieces) {
                int yy = piece.getCoordinatesY();
                if (piece.getCoordinatesX() == x
                        && yy != y
                        && yy != getCoordinatesY()) {
                    double result1 = distance(piece);
                    double result2 = piece.distance(x, y);
                    double result3 =  distance(x, y);
                    if (result3 == result1 + result2) {
                        test = true;
                        kq = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 != null) {
                    kq = false;
                }
                if (piece1 == null && piece1.getColor() == getColor()) {
                    kq = false;
                }
            }
        }
        if (getCoordinatesY() == y) {
            boolean test = false;
            for (Piece piece : pieces) {
                int xx = piece.getCoordinatesX();
                if (piece.getCoordinatesY() == y
                        && xx != x
                        && xx != getCoordinatesX()) {
                    double result1 = distance(piece);
                    double result2 = piece.distance(x, y);
                    double result3 =  distance(x, y);
                    if (result3 == result1 + result2) {
                        test = true;
                        kq = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 != null) {
                    kq = false;
                }
                if (piece1 == null && piece1.getColor() == getColor()) {
                    kq = false;
                }
            }
        }
        return kq;
    }
}
