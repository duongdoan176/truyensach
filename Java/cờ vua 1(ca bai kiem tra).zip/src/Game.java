import java.util.ArrayList;

public class Game {
    private Board board;
    private ArrayList<Move> moveHistory = new ArrayList<>();

    /**
     * game.
     */
    public Game(Board board) {
        this.board = board;
    }

    /**
     * movepiece.
     */
    public void movePiece(Piece piece, int x, int y) {
        Piece piece1 = board.getAt(x, y);
        if (piece.canMove(board, x, y) && piece1 == null) {
            Move move = new Move(piece.getCoordinatesX(), x, piece.getCoordinatesY(), y, piece);
            moveHistory.add(move);
            piece.setCoordinatesX(x);
            piece.setCoordinatesY(y);
        }
        if (piece.canMove(board, x, y) && piece1 != null) {
            Move move
                    = new Move(piece.getCoordinatesX(), x,
                    piece.getCoordinatesY(), y,
                    piece, piece1);
            moveHistory.add(move);
            board.removeAt(x, y);
            piece.setCoordinatesX(x);
            piece.setCoordinatesY(y);
        }
    }

    public ArrayList<Move> getMoveHistory() {
        return moveHistory;
    }

    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }
}
