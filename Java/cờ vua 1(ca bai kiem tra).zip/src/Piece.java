public abstract class Piece {
    private int coordinatesX;
    private int coordinatesY;
    private String color;

    /**
     * piece.
     */
    public Piece(int coordinatesX, int coordinatesY) {
        this.coordinatesX = coordinatesX;
        this.coordinatesY = coordinatesY;
        this.color = "white";
    }

    /**
     * piece.
     */
    public Piece(int coordinatesX, int coordinatesY, String color) {
        this.coordinatesX = coordinatesX;
        this.coordinatesY = coordinatesY;
        this.color = color;
    }

    /**
     * piece.
     */
    public int getCoordinatesX() {
        return coordinatesX;
    }

    /**
     * piece.
     */
    public void setCoordinatesX(int coordinatesX) {
        this.coordinatesX = coordinatesX;
    }

    /**
     * piece.
     */
    public int getCoordinatesY() {
        return coordinatesY;
    }

    /**
     * piece.
     */
    public void setCoordinatesY(int coordinatesY) {
        this.coordinatesY = coordinatesY;
    }

    /**
     * piece.
     */
    public String getColor() {
        return color;
    }

    /**
     * piece.
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * piece.
     */
    public abstract String getSymbol();

    /**
     * piece.
     */
    public abstract boolean canMove(Board board, int x, int y);

    /**
     * piece.
     */
    public boolean checkPosition(Piece piece) {
        return coordinatesX == piece.getCoordinatesX()
                && coordinatesY == piece.getCoordinatesY();
    }

    /**
     * distance.
     */
    public double distance(Piece piece) {
        double tong = Math.pow((coordinatesX - piece.getCoordinatesX()), 2)
                + Math.pow((coordinatesY - piece.getCoordinatesY()), 2);
        return Math.sqrt(tong);
    }

    /**
     * distance.
     */
    public double distance(int x, int y) {
        double tong = Math.pow((coordinatesX - x), 2)
                + Math.pow((coordinatesY - y), 2);
        return Math.sqrt(tong);
    }
}
