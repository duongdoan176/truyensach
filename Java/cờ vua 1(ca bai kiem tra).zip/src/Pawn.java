import java.util.ArrayList;

public class Pawn extends Piece {
    /**
     * pawn.
     */
    public Pawn(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    /**
     * pawn.
     */
    public Pawn(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    @Override
    public String getSymbol() {
        return "";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        boolean kq = false;
        ArrayList<Piece> pieces = board.getPieces();
        if (getColor().equals("black")) {
            if (y >= getCoordinatesY()) {
                return false;
            } else {
                double distance = distance(x, y);
                Piece piece = board.getAt(x, y);
                if (piece != null) {
                    if (dis == Math.sqrt(2) && piece.getColor().equals("white")) {
                        kq = true;
                    }
                }
                if (getCoordinatesX() == x) {
                    if (getCoordinatesY() - y == 1 && piece == null) {
                        kq = true;
                    }
                    if (getCoordinatesY() == 7 && y == 5
                            && board.getAt(x, 6) == null) {
                        kq = true;
                    }
                }
            }
        }
        if (getColor().equals("white")) {
            if (y <= getCoordinatesY()) {
                return false;
            } else {
                double distance = distance(x, y);
                Piece piece = board.getAt(x, y);
                if (piece != null) {
                    if (distance == Math.sqrt(2) && piece.getColor().equals("black")) {
                        kq = true;
                    }
                }
                if (getCoordinatesX() == x) {
                    if (y - getCoordinatesY() == 1 && piece == null) {
                        kq = true;
                    }
                    if (getCoordinatesY() == 2 && y == 4
                            && board.getAt(x, 3) == null) {
                        kq = true;
                    }
                }
            }
        }
        return kq;
    }
}
