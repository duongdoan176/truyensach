import java.util.ArrayList;

public class Bishop extends Piece {
    /**
     * Bishop chess.
     */
    public Bishop(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    /**
     * Bishop chess.
     */
    public Bishop(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    @Override
    public String getSymbol() {
        return "B";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        boolean result = false;
        ArrayList<Piece> pieces = board.getPieces();
        int tong = x + y;
        int hieu = x - y;
        if (getCoordinatesX() + getCoordinatesY() == tong
                && getCoordinatesX() - getCoordinatesY() == hieu) {
            return true;
        }
        if (getCoordinatesX() + getCoordinatesY() == tong) {
            boolean test = false;
            for (Piece piece : pieces) {
                int tong1 = piece.getCoordinatesX() + piece.getCoordinatesY();
                if (tong1 == tong
                        && piece.getCoordinatesX() != x
                        && piece.getCoordinatesY() != y
                        && piece.getCoordinatesX() != getCoordinatesX()
                        && piece.getCoordinatesY() != getCoordinatesY()) {
                    double kq1 = Math.round(distance(piece) * 1000.0) / 1000.0;
                    double kq2 = Math.round(piece.distance(x, y) * 1000.0) / 1000.0;
                    double kq3 = Math.round(distance(x, y) * 1000.0) / 1000.0;
                    if (kq3 == kq1 + kq2) {
                        test = true;
                        result = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 == null) {
                    result = true;
                }
                if (piece1 != null && piece1.getColor() != getColor()) {
                    result = true;
                }
            }
        }
        if (getCoordinatesX() - getCoordinatesY() == hieu) {
            boolean test = false;
            for (Piece piece : pieces) {
                int hieu1 = piece.getCoordinatesX() - piece.getCoordinatesY();
                if (hieu1 == hieu
                        && piece.getCoordinatesX() != x
                        && piece.getCoordinatesY() != y
                        && piece.getCoordinatesX() != getCoordinatesX()
                        && piece.getCoordinatesY() != getCoordinatesY()) {
                    double kq1 = Math.round(distance(piece) * 1000.0) / 1000.0;
                    double kq2 = Math.round(piece.distance(x, y) * 1000.0) / 1000.0;
                    double kq3 = Math.round(distance(x, y) * 1000.0) / 1000.0;
                    if (kq3 == kq1 + kq2) {
                        test = true;
                        result = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 == null) {
                    result = true;
                }
                if (piece1 != null && piece1.getColor() != getColor()) {
                    result = true;
                }
            }
        }
        return result;
    }
}
