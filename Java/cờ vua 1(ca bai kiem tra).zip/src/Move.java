public class Move {
    private int startX;
    private int endX;
    private int startY;
    private int endY;
    private Piece movedPiece;
    private Piece killedPiece;

    /**
     * move.
     */
    public Move(int startX, int endX, int startY, int endY, Piece movedPiece, Piece killedPiece) {
        this.startX = startX;
        this.endX = endX;
        this.startY = startY;
        this.endY = endY;
        this.movedPiece = movedPiece;
        this.killedPiece = killedPiece;
    }

    /**
     * move.
     */
    public Move(int startX, int endX, int startY, int endY, Piece movedPiece) {
        this.startX = startX;
        this.endX = endX;
        this.startY = startY;
        this.endY = endY;
        this.movedPiece = movedPiece;
    }

    /**
     * move.
     */
    public int getStartX() {
        return startX;
    }

    /**
     * move.
     */
    public void setStartX(int startX) {
        this.startX = startX;
    }

    /**
     * move.
     */
    public int getEndX() {
        return endX;
    }

    /**
     * move.
     */
    public void setEndX(int endX) {
        this.endX = endX;
    }

    /**
     * move.
     */
    public int getStartY() {
        return startY;
    }

    /**
     * move.
     */
    public void setStartY(int startY) {
        this.startY = startY;
    }

    /**
     * move.
     */
    public int getEndY() {
        return endY;
    }

    /**
     * move.
     */
    public void setEndY(int endY) {
        this.endY = endY;
    }

    /**
     * move.
     */
    public Piece getMovedPiece() {
        return movedPiece;
    }

    /**
     * move.
     */
    public void setMovedPiece(Piece movedPiece) {
        this.movedPiece = movedPiece;
    }

    /**
     * move.
     */
    public Piece getKilledPiece() {
        return killedPiece;
    }

    /**
     * move.
     */
    public void setKilledPiece(Piece killedPiece) {
        this.killedPiece = killedPiece;
    }

    @Override
    public String toString() {
        String info = "" + (char) ('a' + endX - 1) + endY;
        return movedPiece.getColor() + "-" + movedPiece.getSymbol() + info + "/n";
    }
}
