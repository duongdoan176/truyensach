public class King extends Piece {
    /**
     * king.
     */
    public King(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    /**
     * king.
     */
    public King(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    @Override
    public String getSymbol() {
        return "K";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        boolean kq = true;
        double distance = distance(x, y);
        if (distance != Math.sqrt(2) && distance != 1) {
            return false;
        } else {
            Piece piece = board.getAt(x, y);
            if (piece != null) {
                kq = false;
            }
            if (piece == null && piece.getColor() == getColor()) {
                kq = false;
            }
        }
        return kq;
    }
}
