import java.util.ArrayList;

public class Rook extends Piece {
    /**
     * rook.
     */
    public Rook(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    /**
     * rook.
     */
    public Rook(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    @Override
    public String getSymbol() {
        return "R";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        boolean kq = false;
        ArrayList<Piece> pieces = board.getPieces();
        if (getCoordinatesX() != x && getCoordinatesY() != y) {
            return false;
        }
        if (getCoordinatesX() == x) {
            boolean test = false;
            for (Piece piece : pieces) {
                int yy = piece.getCoordinatesY();
                if (piece.getCoordinatesX() == x
                        && yy != y
                        && yy != getCoordinatesY()) {
                    double result1 = distance(piece);
                    double result2 = piece.distance(x, y);
                    double result3 =  distance(x, y);
                    if (result3 == result1 + result2) {
                        test = true;
                        kq = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 == null) {
                    kq = true;
                }
                if (piece1 != null && piece1.getColor() != getColor()) {
                    kq = true;
                }
            }
        }
        if (getCoordinatesY() == y) {
            boolean test = false;
            for (Piece piece : pieces) {
                int xx = piece.getCoordinatesX();
                if (piece.getCoordinatesY() == y
                        && xx != x
                        && xx != getCoordinatesX()) {
                    double result1 = distance(piece);
                    double result2 = piece.distance(x, y);
                    double result3 =  distance(x, y);
                    if (result3 == result1 + result2) {
                        test = true;
                        kq = false;
                        break;
                    }
                }
            }
            if (! test) {
                Piece piece1 = board.getAt(x, y);
                if (piece1 == null) {
                    kq = true;
                }
                if (piece1 != null && piece1.getColor() != getColor()) {
                    kq = true;
                }
            }
        }
        return kq;
    }
}
