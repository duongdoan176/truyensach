public class Knight extends Piece {
    /**
     * knight.
     */
    public Knight(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    /**
     * knight.
     */
    public Knight(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    @Override
    public String getSymbol() {
        return "N";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        boolean kq = true;
        double dis = distance(x, y);
        if (dis != Math.sqrt(5)) {
            return false;
        } else {
            Piece piece = board.getAt(x, y);
            if (piece != null) {
                kq = false;
            }
            if (piece == null && piece.getColor() == getColor()) {
                kq = false;
            }
        }
        return kq;
    }
}
