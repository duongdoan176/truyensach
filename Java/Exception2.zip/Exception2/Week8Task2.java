import java.io.File;        
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Week8Task2 {
    /**
     * Throws NullPointerException.
     */
    public static void nullPointerEx() throws NullPointerException {
        Object obj = null;
        obj.toString();
    }

    /**
     * Test NullPointerException.
     */
    public static String nullPointerExTest() {
        try {
            nullPointerEx();
            return "Không có lỗi";
        } catch (NullPointerException e) {
            return "Lỗi Null Pointer";
        }
    }

    /**
     * Throws ArrayIndexOutOfBoundsException.
     */
    public static void arrayIndexOutOfBoundsEx() throws ArrayIndexOutOfBoundsException {
        int[] arr = {1, 2, 4};
        System.out.println(arr[4]);
    }

    /**
     * Test ArrayIndexOutOfBoundsException.
     */
    public static String arrayIndexOutOfBoundsExTest() {
        try {
            arrayIndexOutOfBoundsEx();
            return "Không có lỗi";
        } catch (ArrayIndexOutOfBoundsException e) {
            return "Lỗi Array Index Out of Bounds";
        }
    }

    /**
     * Throws ArithmeticException.
     */
    public static void arithmeticEx() throws ArithmeticException {
        int a = 10;
        int b = 0;
        System.out.println(a / b);
    }

    /**
     * Test ArithmeticException.
     */
    public static String arithmeticExTest() {
        try {
            arithmeticEx();
            return "Không có lỗi";
        } catch (ArithmeticException e) {
            return "Lỗi Arithmetic";
        }
    }

    /**
     * Throws FileNotFoundException.
     */
    public static void fileNotFoundEx() throws FileNotFoundException {
        FileReader file = new FileReader("documents.txt");
        System.out.println(file.hashCode());
    }

    /**
     * Test FileNotFoundException.
     */
    public static String fileNotFoundExTest() {
        try {
            fileNotFoundEx();
            return "Không có lỗi";
        } catch (FileNotFoundException e) {
            return "Lỗi File Not Found";
        }
    }

    /**
     * Throws IOException.
     */
    public static void ioEx() throws IOException {
        File file = new File("documents.txt");
        FileInputStream fileInputStream;
        fileInputStream = new FileInputStream(file);
        fileInputStream.read();
    }

    /**
     * Test IOException.
     */
    public static String ioExTest() {
        try {
            ioEx();
            return "Không có lỗi";
        } catch (IOException e) {
            return "Lỗi IO";
        }
    }
}
