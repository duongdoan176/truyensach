public class Point {
    private double pointX;
    private double pointY;

    public Point(double pointX, double pointY) {
        this.pointX = pointX;
        this.pointY = pointY;
    }

    public double getPointX() {
        return pointX;
    }

    public void setPointX(double pointX) {
        this.pointX = pointX;
    }

    public double getPointY() {
        return pointY;
    }

    public void setPointY(double pointY) {
        this.pointY = pointY;
    }

    /**
     * java.
     */
    public double distance(Point other) {
        double result = Math.pow((pointY - other.getPointY()), 2)
                + Math.pow((pointX - other.getPointX()), 2);
        return Math.sqrt(result);
    }

    public String getInfo() {
        return "(" + String.format("%.2f", pointX)
                + "," + String.format("%.2f", pointY) + ")";
    }

    /**
     * java.
     */
    public boolean inAStraight(Point other1, Point other2) {
        double poi1 = distance(other1);
        double poi2 = distance(other2);
        double poi3 = other1.distance(other2);
        return poi1 + poi2 == poi3 || poi1 + poi3 == poi2;
    }
}
