import java.util.List;

public class ShapeUtil {

    /**
     * java.
     */
    public String printInfo(List<GeometricObject> shapes) {
        String results = "Circle:";
        for (GeometricObject shape : shapes) {
            if (shape instanceof Circle) {
                results = results + "\n" + shape.getInfo();
            }
        }
        results = results + "\n" + "Triangle:";
        for (GeometricObject shape : shapes) {
            if (shape instanceof Triangle) {
                results = results + "\n" + shape.getInfo();
            }
        }
        return results;
    }
}
