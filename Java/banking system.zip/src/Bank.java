import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Bank {
    private List<Customer> customerList = new ArrayList<>();

    public List<Customer> getCustomerList() {
        return customerList;
    }

    /**
     * readcustomer.
     */
    public void readCustomerList(InputStream inputStream) {
        Scanner input = new Scanner(inputStream);
        List<String> strings = new ArrayList<>();
        while (input.hasNextLine()) {
            String curentLine = input.nextLine();
            strings.add(curentLine);
        }
        Customer customer = new Customer(0, "");
        CheckingAccount checkingAccount = new CheckingAccount(0, 0);
        SavingsAccount savingsAccount = new SavingsAccount(0, 0);
        for (int i = 0; i < strings.size(); i++) {
            if (strings.get(i).charAt(0) >= '0' && strings.get(i).charAt(0) <= '9') {
                String[] splits1 = strings.get(i).split(" ");
                long accountNumber = Long.parseLong(splits1[0]);
                double balance = Double.parseDouble(splits1[2]);
                if (splits1[1] == Account.CHECKING) {
                    checkingAccount = new CheckingAccount(accountNumber, balance);
                    customer.addAccount(checkingAccount);
                }
                if (splits1[1] == Account.SAVINGS) {
                    savingsAccount = new SavingsAccount(accountNumber, balance);
                    customer.addAccount(savingsAccount);
                }
            } else {
                String[] splits = strings.get(i).split(" ");
                int size = splits.length;
                String fullName = splits[0];
                for (int j = 1; j < size - 1; j++) {
                    fullName = fullName + " " + splits[j];
                }
                long idNumber = Long.parseLong(splits[size - 1]);
                customer = new Customer(idNumber, fullName);
            }
            if (i + 1 < strings.size()) {
                if (strings.get(i + 1).charAt(0) >= 'A' && strings.get(i).charAt(0) <= 'Z') {
                    customerList.add(customer);
                }
            } else if (i + 1 == strings.size()) {
                customerList.add(customer);
            }
        }
    }

    /**
     * idorder.
     */
    public String getCustomersInfoByIdOrder() {
        customerList.sort(Comparator.comparing(Customer::getIdNumber));
        String output = customerList.get(0).getCustomerInfo();
        for (int i = 1; i < customerList.size(); i++) {
            output = output + "\n" + customerList.get(i).getCustomerInfo();
        }
        return output;
    }

    /**
     * name.
     */
    public String getCustomersInfoByNameOrder() {
        customerList.sort(Comparator.comparing(Customer::getFullName));
        String output = customerList.get(0).getCustomerInfo();
        for (int i = 1; i < customerList.size(); i++) {
            output = output + "\n" + customerList.get(i).getCustomerInfo();
        }
        return output;
    }
}