import java.util.ArrayList;
import java.util.List;

public class Customer {
    private long idNumber;
    private String fullName;
    private List<Account> accountList = new ArrayList<>();

    /**
     * customer.
     */
    Customer() {

    }

    /**
     * customer.
     */
    Customer(long idNumber, String fullName) {
        this.idNumber = idNumber;
        this.fullName = fullName;
    }

    /**
     * customer get.
     */
    public String getCustomerInfo() {
        return "Số CMND: " + idNumber
                + ". Họ tên: " + fullName + ".";
    }

    /**
     * addaccount.
     */
    public void addAccount(Account account) {
        boolean test = false;
        for (Account account1 : accountList) {
            if (account1.equals(account)) {
                test = true;
                break;
            }
        }
        if (!test) {
            accountList.add(account);
        }
    }

    /**
     * removeacount.
     */
    public void removeAccount(Account account) {
        for (int i = 0; i < accountList.size(); i++) {
            if (accountList.get(i).equals(account)) {
                accountList.remove(i);
            }
        }
    }

    /**
     * customer.
     */
    public List<Account> getAccountList() {
        return accountList;
    }

    /**
     * customer.
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * customer.
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * customer.
     */
    public long getIdNumber() {
        return idNumber;
    }

    /**
     * customer.
     */
    public void setIdNumber(long idNumber) {
        this.idNumber = idNumber;
    }
}
