public class Transaction {
    public static final int TYPE_DEPOSIT_CHECKING = 1;
    public static final int TYPE_WITHDRAW_CHECKING = 2;
    public static final int TYPE_DEPOSIT_SAVINGS = 3;
    public static final int TYPE_WITHDRAW_SAVINGS = 4;
    private int type;
    private double amount;
    private double initialBalance;
    private double finalBalance;

    /**
     * transaction.
     */
    public Transaction(int type, double amount, double initialBalance, double finalBalance) {
        this.type = type;
        this.amount = amount;
        this.initialBalance = initialBalance;
        this.finalBalance = finalBalance;
    }

    /**
     * get transaction.
     */
    public String getTransactionTypeString(int type) {
        String output = "";
        if (type == TYPE_DEPOSIT_CHECKING) {
            output = "Nạp tiền vãng lai";
        }
        if (type == TYPE_WITHDRAW_CHECKING) {
            output = "Rút tiền vãng lai";
        }
        if (type == TYPE_DEPOSIT_SAVINGS) {
            output = "Nạp tiền tiết kiệm";
        }
        if (type == TYPE_WITHDRAW_SAVINGS) {
            output = "Rút tiền tiết kiệm";
        }
        return output;
    }

    /**
     * Return transaction info.
     */
    public String getTransactionSummary() {
        String amt = String.format("%.2f", amount);
        String intBlc = String.format("%.2f", initialBalance);
        String finalBlc = String.format("%.2f", finalBalance);
        return "- Kiểu giao dịch: " + getTransactionTypeString(type)
                + ".Số dư ban đầu: $" + intBlc
                + ". Số tiền: $" + amt
                + ". Số dư cuối: $" + finalBlc + ".";
    }
}
