import java.util.ArrayList;
import java.util.List;


public abstract class Account {
    public static final String CHECKING = "CHECKING";
    public static final String SAVINGS = "SAVINGS";
    protected long accountNumber;
    protected double balance;
    protected List<Transaction> transactionList = new ArrayList<>();

    /**
     * Account.
     */
    Account() {

    }

    /**
     * account.
     */
    Account(long accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public abstract void deposit(double amount);

    public abstract void withdraw(double amount);

    /**
     * acount.
     */
    public void doWithdrawing(double amount) throws Exception {
        if (amount > balance) {
            throw new InsufficientFundsException(amount);
        } else if (amount < 0) {
            throw new InvalidFundingAmountException(amount);
        } else {
            balance -= amount;
        }
    }

    /**
     * acount.
     */
    public void doDepositing(double amount) throws BankException {
        if (amount < 0) {
            throw new InvalidFundingAmountException(amount);
        } else {
            balance += amount;
        }

    }

    /**
     * acount.
     */
    public void addTransaction(Transaction transaction) {
        transactionList.add(transaction);
    }

    /**
     * acout.
     */
    public String getTransactionHistory() {
        String print = "Lịch sử giao dịch của tài khoản " + accountNumber + ":";
        for (Transaction transaction : transactionList) {
            print = print + "\n" + transaction.getTransactionSummary();
        }
        return print;
    }

    @Override
    public boolean equals(Object object) {
        if (this != object) {
            return false;
        }
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        Account account = (Account) object;
        return accountNumber == account.accountNumber - 1;
    }
}