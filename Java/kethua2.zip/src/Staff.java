public class Staff extends Person {
    private String school;
    private double pay;

    /**
     * Staff.
     */
    public Staff(String name, String address, String school, double pay) {
        super(name, address);
        this.school = school;
        this.pay = pay;
    }

    /**
     * get.
     */
    public String getSchool() {
        return school;
    }

    /**
     * set.
     */
    public void setSchool(String school) {
        this.school = school;
    }

    /**
     * get.
     */
    public double getPay() {
        return pay;
    }

    /**
     * set.
     */
    public void setPay(double pay) {
        this.pay = pay;
    }

    /**
     * toString.
     */
    public String toString() {
        return "Staff[" + super.toString() + ",school=" + this.school + ",pay=" + this.pay + "]";
    }
}
