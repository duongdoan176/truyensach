public class Person {
    private String name;
    private String address;

    /**
     * Person.
     */
    public Person(String name, String address) {
        this.name = name;
        this.address = address;
    }

    /**
     * get.
     */
    public String getName() {
        return name;
    }

    /**
     * set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * get.
     */
    public String getAddress() {
        return address;
    }

    /**
     * set.
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * toString.
     */
    public String toString() {
        return "Person[name=" + this.name + ",address=" + this.address + "]";
    }
}
