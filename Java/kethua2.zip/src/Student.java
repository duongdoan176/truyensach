public class Student extends Person {
    private String program;
    private int year;
    private double fee;

    /**
     * Student.
     */
    public Student(String name, String address, String program, int year, double fee) {
        super(name, address);
        this.program = program;
        this.year = year;
        this.fee = fee;
    }

    /**
     * get.
     */
    public String getProgram() {
        return program;
    }

    /**
     * setet.
     */
    public void setProgram(String program) {
        this.program = program;
    }

    /**
     * get.
     */
    public int getYear() {
        return year;
    }

    /**
     * set.
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * get.
     */
    public double getFee() {
        return fee;
    }

    /**
     * set.
     */
    public void setFee(double fee) {
        this.fee = fee;
    }

    /**
     * toString.
     */
    public String toString() {
        return "Student[" + super.toString() + ",program=" + this.program + ",year=" + this.year
                          + ",fee=" + this.fee + "]";
    }
}
