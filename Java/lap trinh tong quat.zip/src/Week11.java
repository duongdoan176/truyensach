import java.util.List;

public class Week11 {
    /**
     * gênric.
     */
    public static <T extends Comparable> List<T> sortGeneric(List<T> array) {
        for (int i = 0; i < array.size(); i++) {
            for (int j = i + 1; j < array.size(); j++) {
                if (array.get(i).compareTo(array.get(j)) >= 0) {
                    T total = array.get(i);
                    array.set(i, array.get(j));
                    array.set(j, total);
                }
            }
        }
        return array;
    }
}
