public class Person implements Comparable {
    private String name;
    private int age;
    private String address;

    /**
     * person.
     */
    public Person() {

    }

    /**
     * person.
     */
    public Person(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public int compareTo(Object obj) {
        if (obj instanceof Person) {
            Person people = (Person) obj;
            int kq = this.name.compareTo(people.getName());
            if (kq == 0) {
                if (this.age == people.age) {
                    kq = 0;
                } else if (this.age > people.age) {
                    kq = 1;
                } else {
                    kq = -1;
                }
            }
            return kq;
        }
        return -1;
    }
}
