public class Circle extends Shape {
    protected double radius;

    public Circle() {
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getArea() {
        double area = Math.PI * (this.radius * this.radius);
        return area;
    }

    public double getPerimeter() {
        double perimeter = 2 * Math.PI * this.radius;
        return perimeter;
    }

    public String toString() {
        String output = "Circle[radius=" + this.radius 
                        + ",color=" + this.color 
                        + ",filled=" + this.filled + "]";
        return output;
    }
}
