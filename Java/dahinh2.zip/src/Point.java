public class Point {
    private double pointX;
    private double pointY;

    public Point(double pointX, double pointY) {
        this.pointX = pointX;
        this.pointY = pointY;
    }

    public double getPointX() {
        return pointX;
    }

    public void setPointX(double pointX) {
        this.pointX = pointX;
    }

    public double getPointY() {
        return pointY;
    }

    public void setPointY(double pointY) {
        this.pointY = pointY;
    }

    public double distance(Point p) {
        double a = Math.sqrt((this.pointX - p.pointX)
                * (this.pointX - p.pointX) - (this.pointY - p.pointY)
                * (this.pointY - p.pointY));
        return a;
    }

    public boolean equals(Object o) {
        if (o instanceof Point) {
            Point p = (Point) o;
            if (Math.abs(this.pointX - p.pointX) <= 0.001
                    && Math.abs(this.pointY - p.pointY) <= 0.001) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public String toString() {
        String output = "(" + Shape.round(this.pointX) + "," + Shape.round(this.pointY) + ")";
        return output;
    }
}
