public class Circle extends Shape {
    protected Point center;
    protected double radius;

    public Circle() {
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
    }

    public Circle(Point center, double radius, String color, boolean filled) {
        super(color, filled);
        this.center = center;
        this.radius = radius;
    }

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getArea() {
        double area = 3.14 * (this.radius * this.radius);
        return area;
    }

    public double getPerimeter() {
        double perimeter = 2 * 3.14 * this.radius;
        return perimeter;
    }
    public boolean equals(Object o) {
        if (o instanceof Circle) {
            Circle c = (Circle) o;
            if (center.equals(c.center) || Math.abs(this.radius - c.radius) <= 0.001) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public String toString() {
        String str = "Circle[center=" + center.toString() + ",radius=" + Shape.round(this.radius) + ",color=" + this.color + ",filled=" + this.filled + "]";
        return str;
    }
}
