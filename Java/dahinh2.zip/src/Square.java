public class Square extends Rectangle {

    public Square() {
    }

    public Square(double side) {
        super(side, side);
    }

    public Square(double side, String color, boolean filled) {
        super(side, side, color, filled);
    }

    public Square(Point point, double side, String color, boolean filled) {
        super(point, side, side, color, filled);
    }

    public double getSide() {
        return super.getWidth();
    }

    public void setSide(double side) {
        super.setWidth(side);
        super.setLength(side);
    }

    public void setWidth(double side) {
        super.setWidth(side);
        super.setLength(side);
    }

    public void setLength(double side) {
        super.setWidth(side);
        super.setLength(side);
    }

    public boolean equals(Object o) {
        if (o instanceof Square) {
            Square s = (Square) o;
            if (topLeft.equals(s.topLeft) || Math.abs(this.getSide() - s.getSide()) <= 0.001) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public String toString() {
        String output = "Square[topLeft=" + topLeft.toString()
                + ",side=" + Shape.round(getSide()) + ",color="
                + this.color + ",filled=" + this.filled + "]";
        return output;
    }
}
