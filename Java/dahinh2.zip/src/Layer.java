import java.util.ArrayList;
import java.util.List;

public class Layer {
    private List<Shape> shapes = new ArrayList<Shape>();

    public void addShape(Shape s) {
        shapes.add(s);
    }

    public String getInfo() {
        String output = "Layer of crazy shapes:" + "\n";
        for (Shape s : shapes) {
            output += s;
            output += "\n";
        }
        return output;
    }

    public void removeCircles() {
        for (int i = shapes.size() - 1; i >= 0; i--) {
            if (shapes.get(i) instanceof Circle) {
                shapes.remove(i);
            }
        }
    }

    public void removeDuplicates() {
        int a = 0;
        while (a < shapes.size() - 1) {
            int b = a + 1;
            while (b < shapes.size()) {
                if (shapes.get(b).equals(shapes.get(a))) {
                    shapes.remove(b);
                    b--;
                }
                b++;
            }
            a++;
        }
    }
}
