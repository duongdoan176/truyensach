public class Rectangle extends Shape {
    protected Point topLeft;
    protected double width;
    protected double length;

    public Rectangle() {
    }

    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    public Rectangle(double width, double length, String color, boolean filled) {
        super(color, filled);
        this.width = width;
        this.length = length;
    }

    public Rectangle(Point topLeft, double width, double length, String color, boolean filled) {
        super(color, filled);
        this.width = width;
        this.length = length;
        this.topLeft = topLeft;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getArea() {
        double area = this.width * this.length;
        return area;
    }

    public double getPerimeter() {
        double perimeter = 2 * (width + length);
        return perimeter;
    }

    public Point getTopLeft() {
        return topLeft;
    }

    public void setTopLeft(Point topLeft) {
        this.topLeft = topLeft;
    }

    public boolean equals(Object o) {
        if (o instanceof Rectangle) {
            Rectangle r = (Rectangle) o;
            if (Math.abs(this.width - r.width) <= 0.001
                    && Math.abs(this.length - r.length) <= 0.001
                    && topLeft.equals(r.topLeft)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public String toString() {
        String output = "Rectangle[topLeft=" + topLeft.toString()
                + ",width=" + Shape.round(this.width) + ",length="
                + Shape.round(this.length) + ",color="
                + this.color + ",filled=" + this.filled + "]";
        return output;
    }
}
