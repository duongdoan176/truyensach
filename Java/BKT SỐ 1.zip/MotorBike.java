public class MotorBike extends Vehicle {
    private boolean hasSidecar;

    /** An especially short bit of Javadoc. */
    public MotorBike(String brand, String model,
                     String registrationNumber, Person owner,
                     boolean hasSidecar) {
        super(brand, model, registrationNumber, owner);
        this.hasSidecar = hasSidecar;
    }

    /** An especially short bit of Javadoc. */
    @Override
    public String getInfo() {
        String result = "Motor Bike:\n";
        result += "\tBrand: " + super.getBrand() + '\n';
        result += "\tModel: " + super.getModel() + '\n';
        result += "\tRegistration Number: " + super.getRegistrationNumber() + '\n';
        result += "\tHas Side Car: " + this.hasSidecar + '\n';
        result += "\tBelongs to " + super.getOwner().getName();
        result += " - " + super.getOwner().getAddress() + '\n';
        return result;
    }

    /** An especially short bit of Javadoc. */
    public boolean isHasSidecar() {
        return hasSidecar;
    }

    public void setHasSidecar(boolean hasSidecar) {
        this.hasSidecar = hasSidecar;
    }
}
