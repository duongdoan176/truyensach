public class Car extends Vehicle {
    private int numberOfDoors;

    /** An especially short bit of Javadoc. */
    public Car(String brand, String model,
               String registrationNumber, Person owner,
               int numberOfDoors) {
        super(brand, model, registrationNumber, owner);
        this.numberOfDoors = numberOfDoors;
    }

    /** An especially short bit of Javadoc. */
    @Override
    public String getInfo() {
        String result = "Car:\n";
        result += "\tBrand: " + super.getBrand() + '\n';
        result += "\tModel: " + super.getModel() + '\n';
        result += "\tRegistration Number: " + super.getRegistrationNumber() + '\n';
        result += "\tNumber of Doors: " + this.numberOfDoors + '\n';
        result += "\tBelongs to " + super.getOwner().getName();
        result += " - " + super.getOwner().getAddress() + '\n';
        return result;
    }

    /** An especially short bit of Javadoc. */
    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }
}
