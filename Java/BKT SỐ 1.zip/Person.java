import java.util.ArrayList;
import java.util.List;

public class Person {
    private String name;
    private String address;
    private List<Vehicle> vehicleList = new ArrayList<Vehicle>();

    /** An especially short bit of Javadoc. */
    public Person(String name, String address) {
        this.name = name;
        this.address = address;
    }

    /** An especially short bit of Javadoc. */
    public void addVehicle(Vehicle vehicle) {
        vehicleList.add(vehicle);
    }

    /** An especially short bit of Javadoc. */
    public void removeVehicle(String registrationNumber) {
        for (Vehicle vehicle : vehicleList) {
            if (vehicle.getRegistrationNumber() == registrationNumber) {
                vehicleList.remove(vehicle);
            }
        }
    }

    /** An especially short bit of Javadoc. */
    public String getVehiclesInfo() {
        String result = this.name + " has";
        if (vehicleList.size() == 0) {
            result += " no vehicle!";
        } else {
            result += ":\n\n";
            for (Vehicle vehicle : vehicleList) {
                result += vehicle.getInfo();
            }
        }
        return result;
    }

    /** An especially short bit of Javadoc. */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
